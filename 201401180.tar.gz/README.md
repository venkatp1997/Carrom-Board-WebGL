# Carrom-Board-WebGL
Tasks:-
1) Create Carrom Board with 1 red, 4 white, 4 black coins and 4 pockets.

2) Control the location and power of the strike with Mouse & Keyboard.

3) Direction of the strike with Mouse & Keyboard.

4) Power of the strike with Mouse & Keyboard.

5) Perfect Collisions.

